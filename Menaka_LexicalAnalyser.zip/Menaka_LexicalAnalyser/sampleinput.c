/* name:menaka
project:Lexical analyser
*/

#include<stdio.h>
int main()
{
   for( x1 = 0; x1 == 19 ; x++);//for loop
   printf("Hello");
   return 0;

}

