/*Documentation
Name:Menaka.S
Description:
Lexical analysis is the process of converting a sequence of characters
into a sequence of tokens. A program or function which performs lexical analysis is called a lexical
analyzer, lexer, or scanner. A lexer often exists as a single function which is called by a parser or
another function.
Lexical analyzers are designed to recognize keywords , operators , and identifiers , as well
as integers, floating point numbers , character strings , and other similar items that are written as
part of the source program.
*/


#include<stdio.h>
#include<string.h>
#include "lex.h"
#include <ctype.h>

int error_flag = 0; // Initialize error_flag to 0.
// Define arrays for keywords, operators, symbols, and special characters.

// Define arrays for keywords, operators, symbols, and special characters.
char* keyword[] = {
    "goto", "char", "int", "float", "double", "break", "continue", "return",
    "if", "else", "while", "void", "for", "do", "switch", "case", "default",
    "typedef", "struct", "union", "enum", "extern", "static", "volatile",
    "const", "unsigned", "signed", "short", "long", "NULL", "sizeof", "auto",
    "register"
};

char operator[] = {'+', '-', '/', '%', '^', '!', '~', '*', ',', '&', '|', '<', '>', '='}; // Array of operator characters.
char symbol[] = {'{', '}', '[', ']'}; // Array of symbol characters.
char special[] = {'(', ')', ';'}; // Array of special characters.
char delim[] = {'\n', '\t', ' '}; // Array of delimiter characters.

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: ./a.out <.c file>\n");
        return 0;
    }
    char filename[50];
    strcpy(filename, argv[1]);
    if (!strstr(filename, ".c")) {
        printf("Error: Please pass a <.c file>\n");
        return 0;
    }
    FILE* fptr = fopen(filename, "r");
    if (fptr) {
        printf("Open: %s : SUCCESS\n", filename);
    } else {
        printf("Open: %s : FAILED\n", filename);
        return 0;
    }
    printf("Parsing: %s : Started\n", filename);
    lexical_analyze(fptr);
    fclose(fptr);
    if (error_flag) {
        printf("Tokens cannot be generated due to errors.\n");
    } else {
        printf("Tokens generated successfully.\n");
    }
    return 0;
}


void lexical_analyze(FILE* fptr) // Function to perform lexical analysis.
{
    char line[150]; // Buffer to store a line of code.
    int inside_multiline_comment = 0;

    while (fgets(line, sizeof(line), fptr)) // Read line by line from file.
    {
        // Handle multi-line comments
        if (inside_multiline_comment) {
            char *comment_end_multiline = strstr(line, "*/");
            if (comment_end_multiline) {
                inside_multiline_comment = 0;
                char *rest_of_line = comment_end_multiline + 2;
                if (*rest_of_line != '\0') {
                    // Process the remaining part of the line after the end of the comment
                    check_type(rest_of_line);
                }
                continue;
            } else {
                // Skip the entire line as it is inside a multi-line comment
                continue;
            }
        }

        // Check and handle single-line comments
        char *comment_start = strstr(line, "//");
        if (comment_start) {
            *comment_start = '\0'; // Truncate the line at the start of the comment
        }

        // Check and handle multi-line comments that start on the current line
        char *comment_start_multiline = strstr(line, "/*");
        while (comment_start_multiline) {
            char *comment_end_multiline = strstr(comment_start_multiline + 2, "*/");
            if (comment_end_multiline) {
                // Remove comment and process rest of the line
                *comment_start_multiline = '\0';
                comment_end_multiline += 2; // Move past the end of the comment
                if (*comment_end_multiline != '\0') {
                    // Process the remaining part of the line after the end of the comment
                    check_type(comment_end_multiline);
                }
                comment_start_multiline = strstr(comment_end_multiline, "/*");
            } else {
                // Start of a multi-line comment found, continue reading lines
                inside_multiline_comment = 1;
                break;
            }
        }

        if (!inside_multiline_comment) {
            // Process the line if it is not part of a multi-line comment
            if (strlen(line) > 0) {
                check_type(line);
            }
        }
    }
}



void check_type(char* line) // Function to check the type of tokens in a line.
{
    char* temp_line = line; // Temporary pointer to line.
    char arr[50]; // Buffer to store individual tokens.
    int i = 0;

    while (*temp_line) // Loop through each character in the line.
    {
        // Skip delimiters
        if (strchr(delim, *temp_line) != NULL) {
            temp_line++;
            continue;
        }

        // Handle preprocessor directives
        if (*temp_line == '#') {
            // Skip the preprocessor directive and continue processing the rest of the line
            while (*temp_line && *temp_line != '\n') {
                temp_line++;
            }
            // Move to the next line
            if (*temp_line == '\n') {
                temp_line++;
            }
            continue;
        }

        // Check for string literal
        if (*temp_line == '"') {
            temp_line++; // Skip the opening quote
            i = 0; // Reset index for the token buffer
            int in_escape_sequence = 0; // Flag to track escape sequences
            while (*temp_line && *temp_line != '"') {
                if (*temp_line == '\\') { // Check for escape sequence
                    in_escape_sequence = 1; // Set the escape sequence flag
                    arr[i++] = *temp_line++; // Copy backslash
                    if (*temp_line) {
                        arr[i++] = *temp_line++; // Copy the escape sequence character
                    }
                } else {
                    arr[i++] = *temp_line++;
                }
                if (i >= sizeof(arr) - 1) {
                    printf("Error: String literal exceeds buffer size\n");
                    error_flag = 1;
                    break;
                }
            }
            arr[i] = '\0'; // Null-terminate the string

            if (*temp_line == '"') {
                temp_line++; // Skip the closing quote
                printf("%-20s String literal\n", arr); // Print the string literal
            } else {
                printf("ERROR: Closing \" missing\n"); // Print error for missing closing quote
                error_flag = 1;
            }
            continue;
        }

        // Check for character constants
        if (*temp_line == '\'') {
            temp_line++;
            i = 0;
            arr[i++] = *temp_line++;
            if (*temp_line == '\'') {
                printf("%-20c character constant\n", arr[0]); // Print the character constant
                temp_line++;
                continue;
            } else {
                int flag = 0;
                while (*temp_line != '\'' && *temp_line) {
                    if (*temp_line == ';' || *temp_line == ')') flag = 1;
                    arr[i++] = *temp_line++;
                }
                arr[i] = '\0';
                if (flag == 0) {
                    printf("Can't assign %s into a character\n", arr); // Print error for invalid character assignment
                    error_flag = 1;
                } else {
                    printf("Missing of ' single quote\n"); // Print error for missing single quote
                    error_flag = 1;
                }
                if (*temp_line == '\'') temp_line++;
                continue;
            }
        }

        // Check for increment and decrement operators
        if (*temp_line == '+' && *(temp_line + 1) == '+') {
            printf("%-20s Increment operator\n","++");
            temp_line += 2;
            continue;
        }
        if (*temp_line == '-' && *(temp_line + 1) == '-') {
            printf("%-20s Decrement operator\n","--");
            temp_line += 2;
            continue;
        }

        // Check for compound assignment operators
        if (*temp_line == '+') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Compound assignment operator\n","+=");
                temp_line += 2;
                continue;
            }
        }
        else if (*temp_line == '-') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Compound assignment operator\n","-=");
                temp_line += 2;
                continue;
            }
        }
        else if (*temp_line == '*') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Compound assignment operator\n", "*=");
                temp_line += 2;
                continue;
            }
        }
        else if (*temp_line == '/') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Compound assignment operator\n", "/=");
                temp_line += 2;
                continue;
            }
        }
        else if (*temp_line == '%') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Compound assignment operator\n", "%=");
                temp_line += 2;
                continue;
            }
        }

        // Check for relational operators
        if (*temp_line == '=') {
            if (*(temp_line + 1) == '=') {
                printf("%-20s Relational operator\n", "==");
                temp_line += 2;
                continue;
            }
        }
        if (*temp_line == '<' || *temp_line == '>') {
            if (*(temp_line + 1) == '=') {
                printf("%c%-20c Relational operator\n", *temp_line, *(temp_line + 1));
                temp_line += 2;
                continue;
            }
            printf("%-20c Relational operator\n", *temp_line);
            temp_line++;
        }

        // Check for logical and bitwise operators
        if (*temp_line == '&') {
            if (*(temp_line + 1) == '&') {
                printf("%c%-20c Logical operator\n", *temp_line, *(++temp_line));
                temp_line++;
                continue;
            }
            printf("%-20c Bitwise operator\n", *temp_line);
            temp_line++;
        } else if (*temp_line == '|') {
            if (*(temp_line + 1) == '|') {
                printf("%c%-20c Logical operator\n", *temp_line, *(++temp_line));
                temp_line++;
                continue;
            }
            printf("%-20c Bitwise operator\n", *temp_line);
            temp_line++;
        }

        // Check for special characters
        if (is_special(*temp_line)) {
            printf("%-20c Special character\n", *temp_line);
            temp_line++;
            continue;
        }

        // Check for assignment operators
        if (is_assignment(*temp_line)) {
            printf("%-20c Assignment operator\n", *temp_line);
            temp_line++;
            continue;
        }

        // Check for symbols
        if (is_symbol(*temp_line)) {
            printf("%-20c Symbol\n", *temp_line);
            temp_line++;
            continue;
        }

        // Handle tokens
        i = 0;
        while (*temp_line && !strchr(delim, *temp_line) && !is_special(*temp_line) && !is_assignment(*temp_line) && !is_operator(*temp_line) && !is_symbol(*temp_line)) {
            arr[i++] = *temp_line++;
        }
        arr[i] = '\0'; // Null-terminate the string

        if (strlen(arr) > 0) {
            if (!is_keyword(arr) && !is_digit(arr) && !is_bin(arr) && !is_octal(arr) && !is_hexa(arr)) {
                if (*temp_line == '[') {
                    char temp[50];
                    i = strlen(arr);
                    if (*(temp_line + 1) == ']') {
                        strcpy(temp, arr);
                        temp[i++] = *temp_line++;
                        temp[i++] = *temp_line++;
                        temp[i] = '\0';
                        printf("%-20s Array\n", temp);
                    } else {
                        char num[20];
                        strcpy(num, arr);
                        num[strlen(arr)] = '[';
                        num[i + 1] = '\0';
                        int j = 0;
                        temp_line++;
                        while (*temp_line != ']' && *temp_line) {
                            if (*temp_line == ';' || *temp_line == ')') {
                                printf("Missing ] bracket\n");
                                error_flag = 1;
                                break;
                            }
                            num[strlen(arr) + j + 1] = *temp_line++;
                            num[strlen(arr) + j + 2] = '\0';
                            j++;
                        }
                        num[strlen(arr) + j + 1] = ']';
                        num[strlen(arr) + j + 2] = '\0';
                        if (is_digit(num)) {
                            printf("%-20s Array\n", num);
                        } else {
                            printf("Invalid array size\n");
                            error_flag = 1;
                        }
                    }
                } else {
                    printf("%-20s Identifier\n", arr);
                }
            }
        }
    }
}

int is_keyword(char* token) {
    for (int i = 0; i < sizeof(keyword) / sizeof(keyword[0]); i++) {
        if (strcmp(token, keyword[i]) == 0) {
            printf("%-20s Keyword\n", token);
            return 1;
        }
    }
    return 0;
}

int is_digit(char* token) {
    if (token[0] == '0' && strlen(token) > 1) {
        return 0;
    }
    int flag = 0, count = 0, digit_flag = 0;
    for (int i = 0; i < strlen(token); i++) {
        if (token[i] == '.' && !flag) {
            flag = 1;
            count++;
        } else if (isdigit(token[i])) {
            digit_flag++;
        } else {
            return 0;
        }
    }
    if (strlen(token) == digit_flag && flag == 0) {
        printf("%-20s Integer constant\n", token);
        return 1;
    } else if (strlen(token) == digit_flag && flag == 1 && count < 2) {
        printf("%-20s Float constant\n", token);
        return 1;
    } else {
        printf("ERROR: Invalid number %s\n", token);
        error_flag = 1;
        return 1;
    }
    return 0;
}

int is_special(char ch) {
    for (int i = 0; i < sizeof(special); i++) {
        if (ch == special[i])
            return 1;
    }
    return 0;
}

int is_operator(char token) {
    for (int i = 0; i < sizeof(operator); i++) {
        if (token == operator[i])
            return 1;
    }
    return 0;
}

int is_assignment(char ch) {
    return ch == '=';
}

int is_symbol(char ch) {
    for (int i = 0; i < sizeof(symbol); i++) {
        if (ch == symbol[i])
            return 1;
    }
    return 0;
}

int is_bin(char* number) {
    if (strncmp(number, "0b", 2) == 0) {
        for (int i = 2; i < strlen(number); i++) {
            if (number[i] != '0' && number[i] != '1') {
                printf("ERROR: Invalid binary number %s\n", number);
                error_flag = 1;
                return 1;
            }
        }
        printf("%-20s  Binary number\n", number);
        return 1;
    }
    return 0;
}

int is_octal(char* number) {
    if (number[0] == '0' && number[1] != 'x') {
        for (int i = 1; i < strlen(number); i++) {
            if (!(number[i] >= '0' && number[i] <= '7')) {
                printf("ERROR: Invalid octal value %s\n", number);
                error_flag = 1;
                return 1;
            }
        }
        printf("%-20s  Octal value\n", number);
        return 1;
    }
    return 0;
}

int is_hexa(char* number) {
    if (strncmp(number, "0x", 2) == 0) {
        for (int i = 2; i < strlen(number); i++) {
            if (!(isdigit(number[i]) || (number[i] >= 'A' && number[i] <= 'F') || (number[i] >= 'a' && number[i] <= 'f'))) {
                printf("ERROR: Invalid hexadecimal value %s\n", number);
                error_flag = 1;
                return 1;
            }
        }
        printf("%-20s  Hexadecimal value\n", number);
        return 1;
    }
    return 0;
}
