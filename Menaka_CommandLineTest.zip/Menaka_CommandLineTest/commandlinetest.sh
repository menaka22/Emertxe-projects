
<<doc
Name: Menaka
Description: Command line test
command_line_test.sh is a simple shell script designed to provide a basic command-line interface for user registration, login, and test-taking functionality. 
This script aims to offer a straightforward way for users to register,log in, and then participate in a test directly from the command line.
doc

#!/bin/bash

# The file names
USER_FILE="user.csv"
PASSWORD_FILE="password.csv"
USER_ANSWER_FILE="user_answer.txt"
RESULT_FILE="result.txt"
RESULT_VIEW_FILE="result_view.txt"
QUESTION_BANK_FILE="question_bank.txt"
CORRECT_ANSWER_FILE="correct_answer.txt"

# The file paths
DATA_DIR=".TestData"

# The globals
TIMEOUT_PERIOD=10  # Timeout for test questions in seconds

# Create a directory for test data if it doesn't exist
mkdir -p "$DATA_DIR"

# Function to log activities with timestamps
function log() {
    local message="$1"
    echo "$(date +'%Y-%m-%d %H:%M:%S') - $message" >> "$DATA_DIR/activity.log"
}

# Function to create or back up answer file
function answer_file_creation() {
    if [ -e "$USER_ANSWER_FILE" ]; then
        mv "$USER_ANSWER_FILE" "$DATA_DIR/$(date +%Y%m%d%H%M%S)_user_answer.txt"
    fi
    touch "$USER_ANSWER_FILE"
}

# Function to print the welcome menu presentation
function menu_header() {
    echo "------------------------------------------------------------------"
    echo -e "\e[96m                             Welcome\e[39m"
    echo "------------------------------------------------------------------"
    echo -e "\e[96m                       Command Line Test\e[39m"
    echo "------------------------------------------------------------------"
    echo ""
}

# Function to view test results
function view_test_screen() {
    echo "------------------------------------------------------------------"
    echo -e "\e[33mViewing Test Results\e[39m"
    echo "------------------------------------------------------------------"

    if [ ! -e "$USER_ANSWER_FILE" ]; then
        echo "No answers found. Please take the test first."
        return
    fi

    local user_ans
    IFS=$'\n' read -d '' -r -a user_ans < "$USER_ANSWER_FILE"
    local correct_ans
    IFS=$'\n' read -d '' -r -a correct_ans < "$CORRECT_ANSWER_FILE"

    local count=0
    local k=0
    local total_questions=$(wc -l < "$QUESTION_BANK_FILE")

    echo -e "\e[33mTotal Marks Obtained: $(grep -c "correct" "$RESULT_FILE") / $total_questions\e[39m"
    echo "------------------------------------------------------------------"
    echo ""

    for i in $(seq 5 5 50); do
        echo "" >> "$RESULT_VIEW_FILE"
        head -n "$i" "$QUESTION_BANK_FILE" | tail -5 >> "$RESULT_VIEW_FILE"
        echo "" >> "$RESULT_VIEW_FILE"

        case "${user_ans[$k]}" in
            "correct")
                echo -e "\e[92mCorrect Answer\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
            "wrong")
                echo -e "\e[91mWrong Answer\e[39m" >> "$RESULT_VIEW_FILE"
                echo -e "\e[96mCorrect Answer is: ${correct_ans[$k]}\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
            "timeout")
                echo -e "\e[93mTimeout\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
        esac
        k=$((k + 1))
    done

    echo "" >> "$RESULT_VIEW_FILE"
    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    echo -e "\e[33mTotal Correct Answers: $(grep -c "correct" "$RESULT_FILE")\e[39m" >> "$RESULT_VIEW_FILE"
    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    cat "$RESULT_VIEW_FILE" | more

    rm "$USER_ANSWER_FILE" "$RESULT_FILE" "$RESULT_VIEW_FILE"
}

# Function to take the test
function test_screen() {
    clear
    local total_questions=$(wc -l < "$QUESTION_BANK_FILE")
    echo -e "\e[33mTotal Questions: $total_questions\e[39m"
    echo -e "\e[33mTotal Marks: $total_questions\e[39m"
    echo "------------------------------------------------------------------"
    echo ""

    for i in $(seq 5 5 50); do
        echo "************************** ALL THE BEST **************************"
        echo ""
        head -n "$i" "$QUESTION_BANK_FILE" | tail -5
        echo ""

        local option=""
        for j in $(seq $TIMEOUT_PERIOD -1 1); do
            echo -e "\rEnter the choice: $j \c"
            read -t 1 option
            if [ -n "$option" ]; then
                break
            else
                option="e"
            fi
        done
        echo "$option" >> "$USER_ANSWER_FILE"
        clear
        if [ $i -eq 50 ]; then
            echo "************************** TEST OVER **************************" >> "$RESULT_VIEW_FILE"
            break
        fi
    done

    process_results
    display_results
}

# Function to process the test results
function process_results() {
    local user_ans
    IFS=$'\n' read -d '' -r -a user_ans < "$USER_ANSWER_FILE"
    local correct_ans
    IFS=$'\n' read -d '' -r -a correct_ans < "$CORRECT_ANSWER_FILE"
    local ans_count=${#user_ans[@]}
    local count=0

    > "$RESULT_FILE"
    for i in $(seq 0 $(($ans_count - 1))); do
        if [ "${user_ans[$i]}" = "${correct_ans[$i]}" ]; then
            echo "correct" >> "$RESULT_FILE"
            count=$((count + 1))
        elif [ "${user_ans[$i]}" = "e" ]; then
            echo "timeout" >> "$RESULT_FILE"
        else
            echo "wrong" >> "$RESULT_FILE"
        fi
    done
}

# Function to display the results
function display_results() {
    local result
    IFS=$'\n' read -d '' -r -a result < "$RESULT_FILE"
    local correct_ans
    IFS=$'\n' read -d '' -r -a correct_ans < "$CORRECT_ANSWER_FILE"

    > "$RESULT_VIEW_FILE"
    local total_marks=$(grep -c "correct" "$RESULT_FILE")
    local total_questions=$(wc -l < "$QUESTION_BANK_FILE")

    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    echo -e "\e[33mTotal Marks Obtained: $total_marks / $total_questions\e[39m" >> "$RESULT_VIEW_FILE"
    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    echo "" >> "$RESULT_VIEW_FILE"

    local k=0
    for i in $(seq 5 5 50); do
        echo "" >> "$RESULT_VIEW_FILE"
        head -n "$i" "$QUESTION_BANK_FILE" | tail -5 >> "$RESULT_VIEW_FILE"
        echo "" >> "$RESULT_VIEW_FILE"

        case "${result[$k]}" in
            "correct")
                echo -e "\e[92mCorrect Answer\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
            "wrong")
                echo -e "\e[91mWrong Answer\e[39m" >> "$RESULT_VIEW_FILE"
                echo -e "\e[96mCorrect Answer is: ${correct_ans[$k]}\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
            "timeout")
                echo -e "\e[93mTimeout\e[39m" >> "$RESULT_VIEW_FILE"
                ;;
        esac
        k=$((k + 1))
    done

    echo "" >> "$RESULT_VIEW_FILE"
    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    echo -e "\e[33mTotal Correct Answers: $total_marks\e[39m" >> "$RESULT_VIEW_FILE"
    echo "------------------------------------------------------------------" >> "$RESULT_VIEW_FILE"
    cat "$RESULT_VIEW_FILE" | more

    rm "$USER_ANSWER_FILE" "$RESULT_FILE" "$RESULT_VIEW_FILE"
}

# Function to provide a menu for taking test and viewing test
function test_menu() {
    while true; do
        echo "------------------------------------------------------------------"
        echo ""
        echo "1. Take Test"
        echo "2. View Test Results"
        echo "3. Exit"
        echo ""
        echo "------------------------------------------------------------------"
        echo ""
        read choice2

        case $choice2 in
            1)
                answer_file_creation
                test_screen
                ;;
            2)
                view_test_screen
                ;;
            3)
                exit
                ;;
            *)
                echo ""
                echo "Please enter a correct option !!"
                ;;
        esac
    done
}

# Function to handle user sign-in
function sign_in() {
    echo ""
    echo "You have entered --->  2. Sign In"

    local user_name
    IFS=$'\n' read -d '' -r -a user_name < "$USER_FILE"
    local numberofusers=${#user_name[@]}
    local pass_word
    IFS=$'\n' read -d '' -r -a pass_word < "$PASSWORD_FILE"

    while true; do
        echo ""
        read -p "Enter username: " uname
        uname=$(echo "$uname" | tr '[:upper:]' '[:lower:]')

        local username_found=0
        for i in $(seq 0 $(($numberofusers - 1))); do
            if [ "$uname" = "${user_name[$i]}" ]; then
                username_found=1
                break
            fi
        done

        if [ $username_found -eq 0 ]; then
            echo "Username not found. Please try again."
            continue
        fi

        echo -n "Enter password: "
        read -s password
        echo

        local password_correct=0
        for i in $(seq 0 $(($numberofusers - 1))); do
            if [ "$uname" = "${user_name[$i]}" ] && [ "$password" = "${pass_word[$i]}" ]; then
                password_correct=1
                break
            fi
        done

        if [ $password_correct -eq 1 ]; then
            echo "Sign in successful."
            log "User $uname signed in successfully."
            test_menu
        else
            echo "Incorrect password. Please try again."
        fi
    done
}

# Function to handle user sign-up
function sign_up() {
    echo ""
    echo "You have entered --->  1. Sign Up"

    read -p "Enter new username: " new_uname
    new_uname=$(echo "$new_uname" | tr '[:upper:]' '[:lower:]')

    if [ ${#new_uname} -lt 5 ]; then
        echo "Username must be at least 5 characters long."
        return
    fi

    if grep -q "^$new_uname," "$USER_FILE"; then
        echo "Username already exists. Please choose another one."
        return
    fi

    read -s -p "Enter new password: " new_pass
    echo
    if [ ${#new_pass} -lt 8 ]; then
        echo "Password must be at least 8 characters long."
        return
    fi

    echo "$new_uname" >> "$USER_FILE"
    echo "$new_pass" >> "$PASSWORD_FILE"
    echo "Sign up successful."
    log "New user $new_uname signed up successfully."
}

# Main script
echo "Creating necessary files and directories..."
mkdir -p "$DATA_DIR"
touch "$USER_FILE"
touch "$PASSWORD_FILE"

# Main loop
while true; do
    menu_header
    echo "1. Sign Up"
    echo "2. Sign In"
    echo "3. Exit"
    echo -n "Choose an option: "
    read option

    case $option in
        1)
            sign_up
            ;;
        2)
            sign_in
            ;;
        3)
            exit
            ;;
        *)
            echo "Invalid option. Please try again."
            ;;
    esac
done

