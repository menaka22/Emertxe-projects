#include "inverted_search.h"

char *fname;

void create_database(Flist *f_head, Wlist *head[])
{
    //traverse through file LL
    while(f_head)
    {
	read_datafile(f_head, head, f_head -> file_name);
	f_head = f_head->link;
    }
}

Wlist * read_datafile(Flist *file, Wlist *head[], char *filename)
{
    //initialization
    int flag;
    fname = filename;

    //declaration
    char word[WORD_SIZE];

    //opening file in read mode
    FILE *fptr = fopen(filename , "r");

    //reading words from the file
    while(fscanf(fptr, "%s", word) != EOF)
    {
	//reset flag after each new word fetch
	flag = 1;

	//index
	int index = tolower(word[0]) % 97;

	// other than alphabets
	if( !(index >=0 && index <= 25))
	{
	    index = 26;
	}

	//if word word list is not empty
	if(head[index] != NULL)
	{
	    Wlist *temp = head[index];

	    //compare the word at each node with new word
	    while(temp)
	    {
		//if duplicate word found
		if(! strcmp(temp->word,word))
		{
		    update_word_count(&temp , filename);

		    //update flag	    
		    flag = 0;

		    break;
		}
		else
		{
		    temp = temp -> link;
		}
	    }

	    if(flag == 1)
	    {
		//words are not repeated
		insert_at_last(&head[index] , word);
	    }
	}

	//if word list is empty
	else if(head[index] == NULL)
	{
	    insert_at_last(&head[index] , word);
	}
    }
}

int update_word_count(Wlist ** head, char * file_name)
{
    Wlist *temp1 = *head;
    if(strcmp(file_name,temp1->Tlink->file_name) == 0)
    {
	((temp1)->Tlink->word_count)++;
         return SUCCESS;
    }
    
    Ltable *temp = (*head)->Tlink;
    while(temp->table_link)
    {
        if(strcmp(file_name,temp->table_link->file_name) == 0){
         (temp->table_link->word_count)++;
         return SUCCESS;
        }
        temp = temp->table_link;
    }
    Ltable *new = malloc(sizeof(Ltable));
    if(new == NULL)
    {
	return FAILURE;
    }
    new->word_count = 1;
    strcpy(new->file_name, file_name);
    new->table_link = NULL;
    (*head)->Tlink->table_link = new;
    ((*head)->file_count)++;
    return SUCCESS;

}














