#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"
#include<string.h>

// Define the DecodeInfo structure
typedef struct {
    FILE *fptr_encoded_image;   // Pointer to the encoded image file
    FILE *fptr_decoded_secret;  // Pointer to the decoded secret file
    char *encoded_image_fname;  // Filename of the encoded image
    char *decoded_fname;        // Filename of the decoded secret
    unsigned long size_secret_file; // Size of the secret file
    char encoded_image_data[8]; // Buffer to hold encoded image data (8 bytes)
} DecodeInfo;

// Function prototypes
Status_d forward_bm_header(DecodeInfo *decodeInfo, int index);
Status_d decode_secret_file_size(DecodeInfo *decodeInfo);
Status_d decode_int_to_lsb(DecodeInfo *decodeInfo);
Status_d open_files_decoding(DecodeInfo *decodeInfo);
Status_d read_and_validate_decode_args(char *argv[], DecodeInfo *decodeInfo);
Status_d decode_magic_string(char *magic_string, DecodeInfo *decodeInfo);
Status_d decode_data_to_image(char *data, int size, DecodeInfo *decodeInfo);
char decode_byte_to_lsb(char *image_buffer);
Status_d decode_byte_to_lsb_secret_data(char *image_buffer);
Status_d decode_secret_file_data(DecodeInfo *decodeInfo);
Status_d do_decoding(DecodeInfo *decodeInfo);

#endif // DECODE_H
