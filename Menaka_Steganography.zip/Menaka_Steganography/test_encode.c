/*
Name:Menaka S
Description:LSB image steganography
Sample input:
Cover Image: beautiful.bmp image.
Secret Message: "My password is SECRET ;)"
Sample output:
Stego Image: The modified BMP image with the secret message embedded.
Extracted Message: Decode the binary data from the stego image to retrieve "MY password is SECRET ;)".
*/

#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "decode.h"
int main(int argc,char *argv[])
{
    //validate cla
    if(argc<2)
    {
        printf("Please pass required input arguments\n");
    }

    else if(argc>5)
    {
        printf("Too many arguments through command line.Please enter valid inputs through CLA\n");
    }

    else
    {


        EncodeInfo E1;
        int ret=check_operation_type(argv);

        if(ret==e_encode)
        {

            if(argc==2)
            {
                printf("Please pass both .bmp file and .txt file as input arguments\n");
            }

            else if(argc==3)
            {
                printf("Please pass both .bmp file and .txt file as input arguments\n");
            }
            else
            {
                printf("Info: Encoding is selected\n");
                if(read_and_validate_encode_args(argv,&E1)== e_success)
                {
                    printf("Info: Read and validate args is success\n");
                    if(do_encoding(&E1) == e_success)
                    {
                        printf("Encoding is success\n");
                    }
                    else
                    {
                        printf("Failed to encode\n");
                        return 6;
                    }

                }
                else
                {
                    printf("Info: Read and validate args is failed\n");
                    return 5;
                }
                //Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);

            }
        }
        else if(ret==e_decode)
        {
            if(argc==2)
            {
                printf("Please pass .bmp file as input arguments\n");
            }
            else
            {

                printf("Info: Decoding is selected\n");
                DecodeInfo decInfo;
                if (read_and_validate_decode_args(argv, &decInfo) == d_success)
                {
                    printf("Read and validate decode arguments is a success");

                    // Function call for do decoding
                    if (do_decoding(&decInfo) == d_success)
                    {
                        printf("Decoding is Success\n");
                    }
                    else
                    {
                        printf("Failed to decode\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("Read and validate decode arguments is a failure\n");
                    return e_failure;
                }
            }
        }
        else
        {
            printf("Error: Unsupported type\n");
            printf("Usage: For Encoding : ./a.out -e beautiful.bmp secret.txt [stego.bmp] \n");
            printf("Usage: For Decoding: ./a.out -d stego.bmp [decoded.txt]\n");
        }
    }
}
OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1],"-e")==0)
        return e_encode;
    else if(strcmp(argv[1],"-d")==0)
        return e_decode;
    else
        e_unsupported;
}

