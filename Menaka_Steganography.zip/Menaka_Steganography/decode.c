#include <stdio.h>
#include "decode.h"
#include "types.h"
#include <string.h>
#include <stdlib.h>
#include "common.h"
Status_d forward_bm_header(DecodeInfo *decodeInfo,int index)
{
    //printf("before %ld",ftell(decodeInfo->fptr_encoded_image));
   fseek(decodeInfo->fptr_encoded_image,index,SEEK_CUR);
    //printf("after %ld",ftell(decodeInfo->fptr_encoded_image));
}
Status_d decode_secret_file_size(DecodeInfo *decodeInfo)
{
     return decode_int_to_lsb(decodeInfo);
}
Status_d decode_int_to_lsb(DecodeInfo *decodeInfo)
{
   //read 32 bytes from rgb
   char str[32];
   fread(str,32,1,decodeInfo->fptr_encoded_image);
   unsigned int data=0;
   // to do: get clear set bit for 32 bit from normal image in all 32 bytes of data in encoded image
   for(int i=0;i<32;i++)
   {
     data=(((str[i]& 01)<<i) | data);
   // str[i]=(str[i] & 0xFE) | ((data>>i)& 1);
   }
   decodeInfo->size_secret_file=data;
  // fwrite(str,32,1,encInfo->fptr_stego_image);
   return d_success;
}
Status_d open_files_decoding(DecodeInfo *decodeInfo)
{
    // Src Image file
    printf("\nEncoded image name %s\n",decodeInfo->encoded_image_fname);
    decodeInfo->fptr_encoded_image = fopen(decodeInfo->encoded_image_fname, "r");
    // Do Error handling
    if (decodeInfo->fptr_encoded_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n",decodeInfo->encoded_image_fname);

        return d_failure;
    }

    
    decodeInfo->fptr_decoded_secret = fopen(decodeInfo->decoded_fname, "w");
    // Do Error handling
    if (decodeInfo->fptr_decoded_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decodeInfo->decoded_fname);
        return d_failure;
    }

    // No failure return e_success
    return d_success;
}
Status_d read_and_validate_decode_args(char *argv[], DecodeInfo *decodeInfo)
{
    // get beautiful.bmp , just the extension ".bmp"
    // get substring, strstr(filename,".") and check whether it is .bmp using strcmp
    if (strcmp(strstr(argv[2], "."), ".bmp") == 0)
    {
        // store filename
        decodeInfo->encoded_image_fname = argv[2];
    }
    else
    {
        printf("Info : Not a .bmp file\n");
        return d_failure;
    }
    
    // output file is passed or not (optional) if not present it will have null pointer
    if (argv[3] != NULL)
    {
        const char *dot=strrchr(argv[3],'.');
        if(!(dot!=NULL && dot !=argv[3]))
        {
            strcat(argv[3],".txt");
            printf("The given file has no extension,hence adding the extension .txt\n");
            decodeInfo->decoded_fname=argv[3];
        }
        if(strcmp(strstr(argv[3],"."),".txt")==0)
        {
            decodeInfo->decoded_fname = argv[3];
        }
        else
        {
            printf("Info: the given file is not a .txt file hence replacing it with a new .txt file\n");
            decodeInfo->decoded_fname= "decoded.txt";
        }
    }

    else
    {
        printf("Info: Output file not mentioned.Creating decoded.txt as default\n");
        decodeInfo->decoded_fname = "decoded.txt";
    }
    return d_success;
}


Status_d decode_magic_string(char *magic_string, DecodeInfo *decodeInfo)
{
    return decode_data_to_image(magic_string,strlen(magic_string), decodeInfo);
}
Status_d decode_data_to_image(char *data, int size, DecodeInfo *decodeInfo)
{
    //printf("size : %d\n",size);
    for(int i=0;i<size;i++)
    { // 8 bytes is stored in image_data
    //printf("ftell : %ld\n",ftell(decodeInfo->fptr_encoded_image));
    fread(decodeInfo->encoded_image_data,8,1,decodeInfo->fptr_encoded_image);
    char index=decode_byte_to_lsb(decodeInfo->encoded_image_data);
    if(index!=data[i])
    {
        printf("Magic string is not present, it is not a encoded image\n");
        return d_failure;
    }
    
    //stored from the image_data from anotehr method will be written to encoded image
    //fwrite(decodeInfo->encoded_image_data,8,1,decodeInfo->fptr_decoded_secret);
    }
    return d_success;
}
char decode_byte_to_lsb(char *image_buffer)
{
    //encode byte to 8 bytes of lsb incase of char
    //result stored in the same array image buffer 
   // int index=7;
    char data=0;
    for(int i=0;i<8;i++)
    {
       // image_buffer[i]=(image_buffer[i] & 1) | ((data>>i)& 1);
        data=(((image_buffer[i]& 01)<<i) | data);
       // index--;
    }
    return data;
}
Status_d decode_byte_to_lsb_secret_data(char *image_buffer)
{
    //encode byte to 8 bytes of lsb incase of char
    //result stored in the same array image buffer 
   // int index=7;
   // char data=0;
    for(int i=0;i<8;i++)
    {
       // image_buffer[i]=(image_buffer[i] & 1) | ((data>>i)& 1);
        image_buffer[i]=(((image_buffer[i]& 01)<<i) | image_buffer[i]);
       // index--;
    }

   // return data;
}
Status_d decode_secret_file_data(DecodeInfo *decodeInfo)
{
 for(int i=0;i<decodeInfo->size_secret_file;i++)
    { // 8 bytes is stored in image_data
    //printf("ftell : %ld\n",ftell(decodeInfo->fptr_encoded_image));
    fread(decodeInfo->encoded_image_data,8,1,decodeInfo->fptr_encoded_image);
   char index= decode_byte_to_lsb(decodeInfo->encoded_image_data);
   // printf("decoded char %c\n",index);
    //stored from the image_data from anotehr method will be written to encoded image
    fprintf(decodeInfo->fptr_decoded_secret,"%c",index);
   // fwrite(decodeInfo->encoded_image_data,8,1,decodeInfo->fptr_decoded_secret);
    }
    return d_success;   
}
Status_d do_decoding(DecodeInfo *decodeInfo)
{
    
    if ((open_files_decoding(decodeInfo)) == d_success)
    {
        printf("Info: Successfully opened the file\n");
      
         forward_bm_header(decodeInfo,54);
              
                if(decode_magic_string(MAGIC_STRING,decodeInfo)==d_success)
                {
                    printf("Magic string successfully decoded\n");
                    
                    forward_bm_header(decodeInfo,(32+32));
                    if(decode_secret_file_size(decodeInfo)==d_success)
                     {
                        printf("Decoded secret file size\n");
                        if(decode_secret_file_data(decodeInfo)==d_success)
                        {
                           printf("Secret file data is decoded, Please check the decoded.txt file to see the decoded msg\n");
                        }
                        else
                        {
                            printf("Failed to decode the secret file data itself\n");
                            return d_failure;
                        }

                     }
                    else
                    {
                        printf("Failed to decode secret file size\n");
                        return d_failure;
                    }
                }
                else
                {
                    printf("Failed to encode magic string\n");
                    return d_failure;
                }
                return d_success;
    }
    else
    {
        printf("Info: failed to  open the file\n");
        return d_failure;
    }
    return d_success;
}
