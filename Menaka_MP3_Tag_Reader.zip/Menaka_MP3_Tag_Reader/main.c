/*

Name:Menaka S
Description:MP3 Tag Reader
The MP3 Tag reader is a Software which will read and display MP3 (ID3) tag information from MP3 files. The software will be Desktop based.
The project will be useful to individuals who wish to View and Collect MP3 tag data.

ID3 is a Metadata Container most often used in conjunction with the MP3 Audio File format. It allows information such as the Title, Artist, Album, 
Track number and other informations about the File tobe stored in the file itself. There are two unrelated versions of ID3: ID3v1 and ID3v2. 
You will have to first detect the ID3 version before getting the tag details.
    
Total 128 bytes are used for storing this Metadata. If you sum the Size of all these fields we see that (30+30+30+4+30+1) equals 125 bytes and not 128 bytes. 
The missing 3 bytes can be found at the very end of the tag before the song title. These 3 bytes are always “TAG” and is the identification that this is indeed an ID3 tag.
As all artists doesn’t have a 30 character name, it is said that if there are some bytes left after the information is entered in the field and those bytes should be filled with the binary value '0'.


 */

#include "mp3.h"

int main(int argc, char*argv[])
{
	//Declare a variable
	int status;

	//Calling function for validation
	status = validate_inputs(argv);


	if (status == SUCCESS)
	{
		if ((strncmp(*(argv + 1),"-v", 2)) == 0)
		{
			status = view(argv);

			if (status == SUCCESS)
			{
				printf("View SUCCESS\n");
			}
			else
			{
				printf("View ERROR\n");
			}
		}
		else if ((strncmp(*(argv + 1),"-e", 2)) == 0)
		{
			status = edit(argv);

			if (status == SUCCESS)
			{
				printf("EDIT SUCCESS\n");
			}
			else
			{
				printf("Edit ERROR\n");
			}
		}
	}
	else if(status == ERROR)
	{
		printf("Validation ERROR\n");
	}
}
