#include "address_book.h"
#include <string.h>
#include <ctype.h>

Contact addressBook[MAX_CONTACTS];
int contactCount;

// Function to check if a phone number is valid
int isValidPhoneNumber(const char* phoneNumber) {
    if (strlen(phoneNumber) != 10) return 0;
    for (int i = 0; i < 10; i++) {
        if (!isdigit(phoneNumber[i])) return 0;
    }
    return 1;
}

// Function to check if an email address is valid
int isValidEmail(const char* email) {
    return strstr(email, "@gmail.com") != NULL && strstr(email, "@") != NULL;
}

// Function to check if a phone number already exists
int phoneNumberExists(const char* phoneNumber) {
    for (int i = 0; i < contactCount; ++i) {
        for (int j = 0; j < addressBook[i].phoneCount; ++j) {
            if (strcmp(addressBook[i].phoneNumbers[j], phoneNumber) == 0) {
                return 1;
            }
        }
    }
    return 0;
}
int contactExists(Contact *contact) {
    for (int i = 0; i < contactCount; ++i) {
        if (strcmp(addressBook[i].name, contact->name) == 0) {
            return i; // Return index of existing contact
        }
    }
    return -1;
}
int phoneNumberInContact(const char* phoneNumber, int contactIndex) {
    for (int i = 0; i < addressBook[contactIndex].phoneCount; ++i) {
        if (strcmp(addressBook[contactIndex].phoneNumbers[i], phoneNumber) == 0) {
            return 1;
        }
    }
    return 0;
}

void updateCSVFile() {
    FILE *file = fopen("contacts.csv", "w");
    if (!file) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < contactCount; ++i) {
        fprintf(file, "%s,", addressBook[i].name);
        for (int j = 0; j < addressBook[i].phoneCount; ++j) {
            fprintf(file, "%s", addressBook[i].phoneNumbers[j]);
            if (j < addressBook[i].phoneCount - 1) fprintf(file, ";");
        }
        fprintf(file, ",%s\n", addressBook[i].email);
    }

    fclose(file);
}


// Function to add a contact
void addContact(void) {
    if (contactCount >= MAX_CONTACTS) {
        printf("Address book is full.\n");
        return;
    }
    
    Contact newContact;
    newContact.phoneCount = 0;

    printf("Enter the name: ");
    fgets(newContact.name, MAX_LENGTH, stdin);
    newContact.name[strcspn(newContact.name, "\n")] = '\0';  // Remove newline character

    // Validate and add phone numbers
    while (1) {
        if (newContact.phoneCount >= MAX_PHONE_NUMBERS) {
            printf("Cannot add more phone numbers.\n");
            break;
        }
        printf("Enter Phone Number %d (10 digits): ", newContact.phoneCount + 1);
        fgets(newContact.phoneNumbers[newContact.phoneCount], MAX_LENGTH, stdin);
        newContact.phoneNumbers[newContact.phoneCount][strcspn(newContact.phoneNumbers[newContact.phoneCount], "\n")] = '\0';  // Remove newline character

        if (isValidPhoneNumber(newContact.phoneNumbers[newContact.phoneCount])) {
            if (phoneNumberExists(newContact.phoneNumbers[newContact.phoneCount])) {
                printf("Phone number already exists. Please enter an alternate phone number.\n");
            } else {
                newContact.phoneCount++;
                printf("Phone number added.\n");
                break;
            }
        } else {
            printf("Invalid phone number. It should be exactly 10 digits.\n");
        }
    }

    // Validate email
    while (1) {
        printf("Enter Email ID: ");
        fgets(newContact.email, MAX_LENGTH, stdin);
        newContact.email[strcspn(newContact.email, "\n")] = '\0';  // Remove newline character
        if (isValidEmail(newContact.email)) {
            break;
        } else {
            printf("Invalid email. It should contain '@gmail.com'.\n");
        }
    }

    // Enter address
    printf("Enter Address: ");
    fgets(newContact.address, MAX_LENGTH, stdin);
    newContact.address[strcspn(newContact.address, "\n")] = '\0';  // Remove newline character

    // Check for duplicate contact
    int existingContactIndex = contactExists(&newContact);
    if (existingContactIndex != -1) {
        // Contact exists, update the phone numbers of the existing contact
        Contact* existingContact = &addressBook[existingContactIndex];
        
        for (int i = 0; i < newContact.phoneCount; ++i) {
            int phoneExists = 0;
            for (int j = 0; j < existingContact->phoneCount; ++j) {
                if (strcmp(existingContact->phoneNumbers[j], newContact.phoneNumbers[i]) == 0) {
                    phoneExists = 1;
                    break;
                }
            }
            if (!phoneExists) {
                if (existingContact->phoneCount < MAX_PHONE_NUMBERS) {
                    strcpy(existingContact->phoneNumbers[existingContact->phoneCount++], newContact.phoneNumbers[i]);
                } else {
                    printf("Cannot add more phone numbers to existing contact.\n");
                }
            }
        }

        // Update email if different
        if (strcmp(existingContact->email, newContact.email) != 0) {
            strcpy(existingContact->email, newContact.email);
        }

        // Update address if different
        if (strcmp(existingContact->address, newContact.address) != 0) {
            strcpy(existingContact->address, newContact.address);
        }

        printf("Contact updated with new phone numbers and/or email and address.\n");
        updateCSVFile();
        return;
    }

    // Add as a new contact
    addressBook[contactCount++] = newContact;
    printf("Contact added successfully.\n");
    updateCSVFile();
}

// Function to list contacts
void listContacts(void) {
    if (contactCount == 0) {
       printf("No contacts available.\n");
        return;
    }
    
    for (int i = 0; i < contactCount; ++i) {
        printf("Contact %d:\n", i + 1);
        printf("Name: %s\n", addressBook[i].name);
        for (int j = 0; j < addressBook[i].phoneCount; ++j) {
            printf("Phone Number %d: %s\n", j + 1, addressBook[i].phoneNumbers[j]);
        }
        printf("Email ID: %s\n", addressBook[i].email);
        printf("Address: %s\n", addressBook[i].address); // Print address
        printf("\n");
    }
}


// Function to search contacts
void searchContact(void) {
    int option;
    printf("Search Contact by:\n");
    printf("0. Back\n");
    printf("1. Name\n");
    printf("2. Phone No\n");
    printf("3. Email ID\n");
    printf("4. Serial No\n");
    printf("Please select an option: ");
    scanf("%d", &option);
    getchar();  // Consume newline character

    char searchQuery[MAX_LENGTH];
    int found = 0;

    switch (option) {
        case 1:
            printf("Enter the Name: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].name, searchQuery) == 0) {
                    printf("S.No: %d\n", i + 1);
                    printf("Name: %s\n", addressBook[i].name);
                    for (int j = 0; j < addressBook[i].phoneCount; ++j) {
                        printf("Phone No %d: %s\n", j + 1, addressBook[i].phoneNumbers[j]);
                    }
                    printf("Email ID: %s\n", addressBook[i].email);
                    printf("Address: %s\n", addressBook[i].address); // Print address
                    printf("\n");
                    found = 1;
                }
            }
            break;
        case 2:
            printf("Enter the Phone No: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                for (int j = 0; j < addressBook[i].phoneCount; ++j) {
                    if (strcmp(addressBook[i].phoneNumbers[j], searchQuery) == 0) {
                        printf("S.No: %d\n", i + 1);
                        printf("Name: %s\n", addressBook[i].name);
                        for (int k = 0; k < addressBook[i].phoneCount; ++k) {
                            printf("Phone No %d: %s\n", k + 1, addressBook[i].phoneNumbers[k]);
                        }
                        printf("Email ID: %s\n", addressBook[i].email);
                        printf("Address: %s\n", addressBook[i].address); // Print address
                        printf("\n");
                        found = 1;
                    }
                }
            }
            break;
        case 3:
            printf("Enter the Email ID: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].email, searchQuery) == 0) {
                    printf("S.No: %d\n", i + 1);
                    printf("Name: %s\n", addressBook[i].name);
                    for (int j = 0; j < addressBook[i].phoneCount; ++j) {
                        printf("Phone No %d: %s\n", j + 1, addressBook[i].phoneNumbers[j]);
                    }
                    printf("Email ID: %s\n", addressBook[i].email);
                    printf("Address: %s\n", addressBook[i].address); // Print address
                    printf("\n");
                    found = 1;
                }
            }
            break;
        case 4:
            printf("Enter the Serial No: ");
            int serialNo;
            scanf("%d", &serialNo);
            getchar();  // Consume newline character
            if (serialNo > 0 && serialNo <= contactCount) {
                printf("S.No: %d\n", serialNo);
                printf("Name: %s\n", addressBook[serialNo - 1].name);
                for (int i = 0; i < addressBook[serialNo - 1].phoneCount; ++i) {
                    printf("Phone No %d: %s\n", i + 1, addressBook[serialNo - 1].phoneNumbers[i]);
                }
                printf("Email ID: %s\n", addressBook[serialNo - 1].email);
                printf("Address: %s\n", addressBook[serialNo - 1].address); // Print address
                printf("\n");
                found = 1;
            } else {
                printf("Invalid Serial No.\n");
            }
            break;
        default:
            printf("Invalid option.\n");
            break;
    }

    if (!found) {
        printf("No matching contact found.\n");
    }
}


// Function to delete a contact
void deleteContact(void) {
    int option;
    printf("Delete Contact by:\n");
    printf("0. Back\n");
    printf("1. Name\n");
    printf("2. Phone No\n");
    printf("3. Email ID\n");
    printf("4. Serial No\n");
    printf("Please select an option: ");
    scanf("%d", &option);
    getchar();  // Consume newline character

    char searchQuery[MAX_LENGTH];
    int found = 0;

    switch (option) {
        case 1:
            printf("Enter the Name: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].name, searchQuery) == 0) {
                    for (int j = i; j < contactCount - 1; ++j) {
                        addressBook[j] = addressBook[j + 1];
                    }
                    contactCount--;
                    printf("Contact deleted successfully.\n");
                    found = 1;
                    break;
                }
            }
            break;
        case 2:
            printf("Enter the Phone No: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                for (int j = 0; j < addressBook[i].phoneCount; ++j) {
                    if (strcmp(addressBook[i].phoneNumbers[j], searchQuery) == 0) {
                        for (int k = i; k < contactCount - 1; ++k) {
                            addressBook[k] = addressBook[k + 1];
                        }
                        contactCount--;
                        printf("Contact deleted successfully.\n");
                        found = 1;
                        break;
                    }
                }
                if (found) break;
            }
            break;
        case 3:
            printf("Enter the Email ID: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].email, searchQuery) == 0) {
                    for (int j = i; j < contactCount - 1; ++j) {
                        addressBook[j] = addressBook[j + 1];
                    }
                    contactCount--;
                    printf("Contact deleted successfully.\n");
                    found = 1;
                    break;
                }
            }
            break;
        case 4:
            printf("Enter Serial No: ");
            int serialNo;
            scanf("%d", &serialNo);
            getchar();  // Consume newline character
            if (serialNo > 0 && serialNo <= contactCount) {
                for (int i = serialNo - 1; i < contactCount - 1; ++i) {
                    addressBook[i] = addressBook[i + 1];
                }
                contactCount--;
                printf("Contact deleted successfully.\n");
                found = 1;
            } else {
                printf("Invalid Serial No.\n");
            }
            break;
        case 0:
            return;
        default:
            printf("Invalid option.\n");
            break;
    }

    if (!found) {
        printf("No contact found.\n");
    }
}


void saveContacts(void) {
    FILE *file = fopen("contacts.csv", "w");
    if (!file) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < contactCount; ++i) {
        fprintf(file, "%s,", addressBook[i].name);

        // Write phone numbers, separated by semicolons
        for (int j = 0; j < addressBook[i].phoneCount; ++j) {
            fprintf(file, "%s", addressBook[i].phoneNumbers[j]);
            if (j < addressBook[i].phoneCount - 1) fprintf(file, ";");
        }
        fprintf(file, ",");

        // Write email
        fprintf(file, "%s,", addressBook[i].email);

        // Write address
        fprintf(file, "%s\n", addressBook[i].address);
    }

    fclose(file);
    printf("Contacts saved successfully.\n");
}


void editContact(void) {
    int option;
    printf("Edit Contact by:\n");
    printf("0. Back\n");
    printf("1. Name\n");
    printf("2. Phone No\n");
    printf("3. Email ID\n");
    printf("4. Address\n");
    printf("5. Serial No\n");
    printf("Please select an option: ");
    scanf("%d", &option);
    getchar();  // Consume newline character

    char searchQuery[MAX_LENGTH];
    int found = 0;

    switch (option) {
        case 1:
            // Edit by Name
            printf("Enter the Name of the contact to edit: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].name, searchQuery) == 0) {
                    printf("Editing contact: %s\n", addressBook[i].name);
                    printf("Enter new name: ");
                    fgets(addressBook[i].name, MAX_LENGTH, stdin);
                    addressBook[i].name[strcspn(addressBook[i].name, "\n")] = '\0';  // Remove newline character
                    printf("Contact updated successfully.\n");
                    found = 1;
                    break;
                }
            }
            break;
        case 2:
            // Edit by Phone No
            printf("Enter the Phone No of the contact to edit: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                for (int j = 0; j < addressBook[i].phoneCount; ++j) {
                    if (strcmp(addressBook[i].phoneNumbers[j], searchQuery) == 0) {
                        printf("Editing phone number: %s\n", addressBook[i].phoneNumbers[j]);

                        char newPhoneNumber[MAX_LENGTH];
                        while (1) {
                            printf("Enter new phone number: ");
                            fgets(newPhoneNumber, MAX_LENGTH, stdin);
                            newPhoneNumber[strcspn(newPhoneNumber, "\n")] = '\0';  // Remove newline character

                            if (!isValidPhoneNumber(newPhoneNumber)) {
                                printf("Invalid phone number. It should be exactly 10 digits.\n");
                            } else if (phoneNumberExists(newPhoneNumber)) {
                                printf("Phone number is already used. Please enter a new one.\n");
                            } else {
                                // Update the phone number
                                strcpy(addressBook[i].phoneNumbers[j], newPhoneNumber);
                                printf("Phone number updated successfully.\n");
                                found = 1;
                                break;
                            }
                        }
                        break;
                    }
                }
                if (found) break;
            }
            break;
        case 3:
            // Edit by Email ID
            printf("Enter the Email ID of the contact to edit: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].email, searchQuery) == 0) {
                    printf("Editing email ID: %s\n", addressBook[i].email);
                    printf("Enter new email ID: ");
                    fgets(addressBook[i].email, MAX_LENGTH, stdin);
                    addressBook[i].email[strcspn(addressBook[i].email, "\n")] = '\0';  // Remove newline character
                    printf("Email ID updated successfully.\n");
                    found = 1;
                    break;
                }
            }
            break;
        case 4:
            // Edit by Address
            printf("Enter the Address of the contact to edit: ");
            fgets(searchQuery, MAX_LENGTH, stdin);
            searchQuery[strcspn(searchQuery, "\n")] = '\0';  // Remove newline character
            for (int i = 0; i < contactCount; ++i) {
                if (strcmp(addressBook[i].address, searchQuery) == 0) {
                    printf("Editing address: %s\n", addressBook[i].address);
                    printf("Enter new address: ");
                    fgets(addressBook[i].address, MAX_LENGTH, stdin);
                    addressBook[i].address[strcspn(addressBook[i].address, "\n")] = '\0';  // Remove newline character
                    printf("Address updated successfully.\n");
                    found = 1;
                    break;
                }
            }
            break;
        case 5:
            // Edit by Serial No
            printf("Enter Serial No of the contact to edit: ");
            int serialNo;
            scanf("%d", &serialNo);
            getchar();  // Consume newline character
            if (serialNo > 0 && serialNo <= contactCount) {
                printf("Editing contact with Serial No: %d\n", serialNo);

                // Edit name
                printf("Enter new name (or press Enter to keep current): ");
                char newName[MAX_LENGTH];
                fgets(newName, MAX_LENGTH, stdin);
                newName[strcspn(newName, "\n")] = '\0';  // Remove newline character
                if (strlen(newName) > 0) {
                    strcpy(addressBook[serialNo - 1].name, newName);
                }

                // Edit email
                printf("Enter new email ID (or press Enter to keep current): ");
                char newEmail[MAX_LENGTH];
                fgets(newEmail, MAX_LENGTH, stdin);
                newEmail[strcspn(newEmail, "\n")] = '\0';  // Remove newline character
                if (strlen(newEmail) > 0) {
                    if (isValidEmail(newEmail)) {
                        strcpy(addressBook[serialNo - 1].email, newEmail);
                    } else {
                        printf("Invalid email format.\n");
                    }
                }

                // Edit address
                printf("Enter new address (or press Enter to keep current): ");
                char newAddress[MAX_LENGTH];
                fgets(newAddress, MAX_LENGTH, stdin);
                newAddress[strcspn(newAddress, "\n")] = '\0';  // Remove newline character
                if (strlen(newAddress) > 0) {
                    strcpy(addressBook[serialNo - 1].address, newAddress);
                }

                // Edit phone numbers
                printf("Edit phone numbers (enter '-1' to stop):\n");
                for (int j = 0; j < addressBook[serialNo - 1].phoneCount; ++j) {
                    printf("Phone Number %d: %s\n", j + 1, addressBook[serialNo - 1].phoneNumbers[j]);
                }
                for (int j = 0; j < addressBook[serialNo - 1].phoneCount; ++j) {
                    printf("Enter new phone number %d (or '-1' to keep current): ", j + 1);
                    char newPhoneNumber[MAX_LENGTH];
                    fgets(newPhoneNumber, MAX_LENGTH, stdin);
                    newPhoneNumber[strcspn(newPhoneNumber, "\n")] = '\0';  // Remove newline character

                    if (strcmp(newPhoneNumber, "-1") == 0) {
                        continue;
                    }

                    if (!isValidPhoneNumber(newPhoneNumber)) {
                        printf("Invalid phone number. It should be exactly 10 digits.\n");
                    } else if (phoneNumberExists(newPhoneNumber)) {
                        printf("Phone number is already used. Please enter a new one.\n");
                    } else {
                        strcpy(addressBook[serialNo - 1].phoneNumbers[j], newPhoneNumber);
                        printf("Phone number updated successfully.\n");
                    }
                }

                printf("Contact updated successfully.\n");
                found = 1;
            } else {
                printf("Invalid Serial No.\n");
            }
            break;
        case 0:
            return;
        default:
            printf("Invalid option.\n");
            break;
    }

    if (!found) {
        printf("No contact found.\n");
    }
}
