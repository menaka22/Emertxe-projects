#ifndef ADDRESS_BOOK_H
#define ADDRESS_BOOK_H

#include <stdio.h>

#define MAX_CONTACTS 100
#define MAX_LENGTH 100
#define MAX_PHONE_NUMBERS 10

// Define the Contact structure
typedef struct {
    char name[MAX_LENGTH];
    char phoneNumbers[MAX_CONTACTS][MAX_LENGTH];
    char email[MAX_LENGTH];
    int phoneCount;
    char address[MAX_LENGTH];
} Contact;

// Global variables
extern Contact addressBook[MAX_CONTACTS];
extern int contactCount;

// Function prototypes
// Function to check if a phone number is valid
int isValidPhoneNumber(const char* phoneNumber);

// Function to check if an email address is valid
int isValidEmail(const char* email);

// Function to check if a phone number already exists
int phoneNumberExists(const char* phoneNumber);

// Function to add a contact
void addContact(void);

// Function to list contacts
void listContacts(void);

// Function to search contacts
void searchContact(void);

// Function to edit a contact
void editContact(void);

// Function to delete a contact
void deleteContact(void);

// Function to save contacts to a CSV file
void saveContacts(void);

#endif // ADDRESS_BOOK_H
