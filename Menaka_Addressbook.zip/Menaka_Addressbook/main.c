/*
Name:Menaka S
Description:Address Book project
Objective: Develop an application to store, manage, and retrieve contact information.
This might include adding, updating, searching, and deleting contacts.
Functionality:
Add Contact: Input details for a new contact and save it.
Update Contact: Modify existing contact details.
Delete Contact: Remove a contact from the address book.
Search Contacts: Find contacts based on various criteria.
View Contacts: Display a list of all contacts or filtered by criteria
*/


#include <stdio.h>
#include <stdlib.h>
#include "address_book.h"

// Function to print the menu
void printMenu() {
    printf("Address Book #######\n");
    printf("0. Exit\n");
    printf("1. Add Contact\n");
    printf("2. Search Contact\n");
    printf("3. Edit Contact\n");
    printf("4. Delete Contact\n");
    printf("5. List Contacts\n");
    printf("6. Save\n");
    printf("Please select an option: ");
}

int main() {
    int option;

    while (1) {
        printMenu();
        scanf("%d", &option);
        getchar();  // Consume newline character

        switch (option) {
            case 0:
                // Prompt to save changes before exiting
                {
                    char saveOption;
                    printf("Enter 'Y' to save changes and 'N' to exit without saving: ");
                    scanf(" %c", &saveOption);
                    getchar();  // Consume newline character
                    if (saveOption == 'Y' || saveOption == 'y') {
                        saveContacts();
                    }
                    printf("Exiting.\n");
                }
                return 0;

            case 1:
                addContact();
                break;

            case 2:
                searchContact();
                break;

            case 3:
                editContact();
                break;

            case 4:
                deleteContact();
                break;

            case 5:
                listContacts();
                break;

            case 6:
                saveContacts();
                break;

            default:
                printf("Invalid option. Please try again.\n");
                break;
        }
    }

    return 0;
}
